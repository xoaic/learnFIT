package com.example.restfulapi2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestfulApi2Application {

    public static void main(String[] args) {
        SpringApplication.run(RestfulApi2Application.class, args);
    }

}
